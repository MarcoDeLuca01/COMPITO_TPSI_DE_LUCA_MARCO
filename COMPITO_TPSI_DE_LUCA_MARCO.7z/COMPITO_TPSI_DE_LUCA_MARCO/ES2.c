#include<stdio.h>

void inverti_capitalizza_stringa(char *str, int n);

int main(void){
    char stringa[10] = "aeiou";
    printf("%s\n", stringa);
    inverti_capitalizza_stringa(stringa, 6);
    printf("%s\n", stringa);
    return 0;
}

void inverti_capitalizza_stringa(char *str, int n) {
    int i = 0;
    int j = n - 1;
    
    while (i < j) {
        char temp = str[i];
        str[i] = str[j];
        str[j] = temp;
        i++;
        j--;
    }

    for (int k = 0; k < n; k++) {
        if (str[k] >= 'a' && str[k] <= 'z') {
            str[k] -= 32;  // Converti in maiuscolo
        }
    }
}
