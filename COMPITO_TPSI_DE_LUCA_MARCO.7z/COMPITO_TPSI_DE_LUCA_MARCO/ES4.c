#include<stdio.h>

int distanza(int a[], int x, int y, int n);

int main(void){
    int a[] = {1,4,3,6,7,2,9,0,5};
    for(int i=0; i<9; i++)
        printf("%d\t", a[i]);
    printf("\n");

    int x = 3;
    int y = 9;
    int d = distanza(a, x, y, 9);
    printf("la distanza tra %d e %d e' di %d posizioni\n", x, y, d);
    return 0;
}

int distanza(int a[], int x, int y, int n) {
    int *px = NULL;
    int *py = NULL;
    
    for (int i = 0; i < n; i++) {
        if (a[i] == x) {
            px = &a[i];
        }
        if (a[i] == y) {
            py = &a[i];
        }
    }
    
    if (px && py) {
        return py - px;
    }
    return -1;  // Elementi non trovati
}
