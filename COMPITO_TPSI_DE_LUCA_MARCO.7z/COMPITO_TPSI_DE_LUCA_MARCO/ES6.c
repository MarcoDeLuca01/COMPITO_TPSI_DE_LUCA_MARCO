#include<stdio.h>
#include<stdlib.h>
#define N 4

void accoda(int **a, int **tail);

int main(void) {
    int *a[N] = {NULL};  // vettore di puntatori
    int *tail = a[0];    // puntatore al primo elemento vuoto di a (all'inizio sono tutti vuoti e tail punta al primo elemento di a)
    
    // Ciclo per chiamare accoda 4 volte
    for (int i = 0; i < N; i++) {
        accoda(a, &tail);
    }

    // Stampa il vettore di puntatori
    for (int i = 0; i < N; i++) {
        printf("%p\t %d\n", a[i], *a[i]);
    }

    printf("\n");
    return 0;
}

void accoda(int *a[], int **tail) {
    int *tmp = (int *)malloc(sizeof(int));
    printf("Inserisci numero: ");
    scanf("%d", tmp);
    printf("\n");

    // Inserimento in coda
    *tail = tmp;
    a[(*tail - a) / sizeof(int)] = tmp;
    *tail = *tail + 1;  // Spostamento del tail alla posizione successiva
}
