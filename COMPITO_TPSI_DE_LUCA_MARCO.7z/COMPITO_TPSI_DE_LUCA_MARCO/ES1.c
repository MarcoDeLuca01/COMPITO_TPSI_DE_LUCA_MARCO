#include <stdio.h>

int main() {
    unsigned int num = 18437;  // Valore intero senza segno 18437
    unsigned char *ptr = (unsigned char *)&num;  // Puntatore al primo byte dell'intero

    for (int i = 0; i < 4; i++) {
        printf("Byte %d: valore esadecimale = %#x, indirizzo di memoria = %p\n", 
               i + 1, ptr[i], (void *)(ptr + i))
    }

    return 0;
}
