#include<stdio.h>
#include<stdlib.h>

void swap(int *a, int *b);

int main(void){
    int a = 5;
    a++;
    int *pa = &a;
    printf("a vale %d, a e' all'indirizzo di memoria %p\n", *pa, pa);
    
    // iterare il vettore con un puntatore
    int b[5] = {1, 2, 3, 4, 5};
    int *pb = b;  // Correzione: puntatore corretto a b
    while(pb < &b[5]){
        printf("%d\t", *pb);
        pb++;
    }
    printf("\n");

    // sostituire in c la stringa miao
    char c[5] = "ciao";
    // c = "miao";  // Questa riga non è valida, non puoi cambiare il puntatore a un array di caratteri statici
    for (int i = 0; i < 5; i++) {
        c[i] = "miao"[i];
    }
    printf("%s\n", c);

    // sostituire in d la stringa miao
    char *d = "ciao";
    // d[0] = 'm';  // Questo genera errore perché le stringhe letterali sono costanti
    d = (char *)malloc(5 * sizeof(char));
    d[0] = 'm';
    d[1] = 'i';
    d[2] = 'a';
    d[3] = 'o';
    d[4] = '\0';
    printf("%s\n", d);

    // invertire il contenuto delle variabili aa e bb
    int aa = 3;
    int bb = 4;
    int *pa1 = &aa, *pb1 = &bb;
    printf("Priva di swap: aa=%d bb=%d\n", *pa1, *pb1);
    swap(pa1, pb1);
    printf("Dopo swap: aa=%d bb=%d\n", *pa1, *pb1);

    free(d);  // Liberiamo la memoria allocata dinamicamente
}

void swap(int *a, int *b){
    int tmp = *a;  // Correzione: dereferenziamo i puntatori
    *a = *b;
    *b = tmp;
}
