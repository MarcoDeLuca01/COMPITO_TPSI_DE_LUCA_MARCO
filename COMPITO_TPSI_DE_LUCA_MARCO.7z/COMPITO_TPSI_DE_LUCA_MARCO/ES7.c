//Marco De Luca 4a INF ES7
#include<stdio.h>

void concatena(char *s1, char *s2, char *s3);
int lunghezza_parola(char *s);

int main(void){
        char s1[100];
        char s2[100];

        printf("Scrivi prima parola: ");
        scanf("%s", s1);

        printf("Scrivi seconda parola: ");
        scanf("%s", s2);

        printf("\n");

        int n_s1 = lunghezza_parola(s1);
        int n_s2 = lunghezza_parola(s2);
        char s3[n_s1 + n_s2 + 1];  // Aggiungi 1 per il carattere di fine stringa \0

        concatena(s1, s2, s3);
        printf("Terza stringa: %s\n", s3);

        return 0;
}

void concatena(char *s1, char *s2, char *s3) {
    while (*s1) {
        *s3 = *s1;
        s1++;
        s3++;
    }
    while (*s2) {
        *s3 = *s2;
        s2++;
        s3++;
    }
    *s3 = '\0';  // Aggiungi il carattere di fine stringa
}

int lunghezza_parola(char *s) {
    int length = 0;
    while (*s) {
        length++;
        s++;
    }
    return length;
}
